const express = require('express');
const passport = require('passport');
const jwt = require('jsonwebtoken');
const router = express.Router();
const { register, login, getProfile } = require('../controllers/authController');

router.post('/register', register);
router.post('/login', login);
router.get('/me', getProfile);

// Rutas Google OAuth
router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

router.get(
  '/google/callback',
  passport.authenticate('google', { session: false, failureRedirect: '/login' }),
  (req, res) => {
    const jwtToken = jwt.sign({ email: req.user.email }, process.env.JWT_SECRET, {
      expiresIn: '1h'
    });

    // Envía el token al frontend usando postMessage
    res.send(`
      <html><body>
        <script>
          window.opener.postMessage("${jwtToken}", "*");
          window.close();
        </script>
      </body></html>
    `);
  }
);

module.exports = router;
