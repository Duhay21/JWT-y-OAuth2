// src/pages/Profile.js
import React from 'react';

function Profile({ user, onLogout }) {
  return (
    <div style={{ maxWidth: 400, margin: 'auto', padding: 20, textAlign: 'center' }}>
      <h2>Perfil del Usuario</h2>
      <p><strong>Nombre:</strong> {user.name}</p>
      <p><strong>Correo:</strong> {user.email}</p>
      <button onClick={onLogout}>Cerrar sesión</button>
    </div>
  );
}

export default Profile;
