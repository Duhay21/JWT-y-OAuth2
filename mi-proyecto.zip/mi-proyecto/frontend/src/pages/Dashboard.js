import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../styles/Dashboard.css';

const Dashboard = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    axios.get('http://localhost:4000/api/auth/me', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setUser(res.data))
      .catch(() => window.location = '/');
  }, []);

  if (!user) return <p>Cargando...</p>;

  return (
    <div className="profile-box">
      <h2>Bienvenido</h2>
      <p><strong>Nombre:</strong> {user.name}</p>
      <p><strong>Email:</strong> {user.email}</p>
      <button onClick={() => { localStorage.removeItem('token'); window.location = '/'; }}>
        Cerrar sesión
      </button>
    </div>
  );
};

export default Dashboard;
