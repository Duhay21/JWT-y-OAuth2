import React, { useState, useEffect } from 'react';
import authService from '../services/authService';
import '../styles/LoginForm.css';

const LoginPage = ({ onLogin }) => {
  const [form, setForm] = useState({ email: '', password: '' });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const data = await authService.loginUser(form.email, form.password);
      localStorage.setItem('token', data.token);
      onLogin(data.user);
    } catch (err) {
      alert('Error al iniciar sesión');
    }
  };

  const handleGoogleLogin = () => {
    const width = 500;
    const height = 600;
    const left = (window.innerWidth - width) / 2;
    const top = (window.innerHeight - height) / 2;

    window.open(
      'http://localhost:4000/api/auth/google',
      '_blank',
      `width=${width},height=${height},left=${left},top=${top}`
    );
  };

  useEffect(() => {
    const handleMessage = (event) => {
      if (typeof event.data === 'string') {
        const token = event.data;
        localStorage.setItem('token', token);

        // Obtener usuario con el token
        fetch('http://localhost:4000/api/auth/me', {
          headers: { Authorization: `Bearer ${token}` }
        })
          .then((res) => res.json())
          .then((data) => {
            if (data.name) {
              onLogin(data);
            }
          });
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onLogin]);

  return (
    <div className="form-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h2>Iniciar Sesión</h2>
        <input
          type="email"
          name="email"
          placeholder="Correo"
          value={form.email}
          onChange={handleChange}
          required
        />
        <input
          type="password"
          name="password"
          placeholder="Contraseña"
          value={form.password}
          onChange={handleChange}
          required
        />
        <button type="submit">Entrar</button>
        <button type="button" className="google-btn" onClick={handleGoogleLogin}>
          Iniciar con Google
        </button>
      </form>
    </div>
  );
};

export default LoginPage;
