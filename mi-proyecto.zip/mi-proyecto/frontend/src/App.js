import React, { useState, useEffect } from 'react';
import LoginForm from './components/LoginForm';
import RegisterForm from './components/RegisterForm';
import Profile from './pages/Profile';

function App() {
  const [user, setUser] = useState(null);
  const [showRegister, setShowRegister] = useState(false);

  // Escucha el postMessage de la ventana Google
  useEffect(() => {
    const handleMessage = (event) => {
      if (typeof event.data === 'string') {
        const token = event.data;
        localStorage.setItem('token', token);

        fetch('http://localhost:4000/api/auth/me', {
          headers: { Authorization: `Bearer ${token}` }
        })
          .then(res => res.json())
          .then(data => {
            if (data.name) {
              setUser(data);
            }
          });
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  // Verifica token si ya existe
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) return;

    fetch('http://localhost:4000/api/auth/me', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        if (data.name) {
          setUser(data);
        } else {
          localStorage.removeItem('token');
        }
      })
      .catch(() => localStorage.removeItem('token'));
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  if (user) {
    return <Profile user={user} onLogout={handleLogout} />;
  }

  return (
    <div>
      {showRegister ? (
        <>
          <RegisterForm onRegister={setUser} />
          <p style={{ textAlign: 'center' }}>
            ¿Ya tienes cuenta?{' '}
            <button onClick={() => setShowRegister(false)}>Inicia sesión</button>
          </p>
        </>
      ) : (
        <>
          <LoginForm onLogin={setUser} />
          <p style={{ textAlign: 'center' }}>
            ¿No tienes cuenta?{' '}
            <button onClick={() => setShowRegister(true)}>Regístrate</button>
          </p>
        </>
      )}
    </div>
  );
}

export default App;
